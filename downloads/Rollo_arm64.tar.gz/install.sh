#!/bin/bash -xe

# rollo arm64 driver
# run this script with sudo
# script Huan Truong 2023 <htruong@tnhh.net>
# rastertolabel_patched from
# https://github.com/proski/cups/commit/9ade138db4387ed016f70feb11a3b7a05daf04ca

cp rastertolabel_patched /usr/lib/cups/filter
cupstestppd Printer_ThermalPrinter.ppd
cp Printer_ThermalPrinter.ppd /usr/share/ppd
